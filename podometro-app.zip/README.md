# Podómetro

App Android (Kotlin + Jetpack Compose): pasos, ruta GPS, clima, aviso por voz cada 1/5/10 km,
objetivos, varios usuarios con peso/altura, calorías e historial.

Compilación: GitHub Actions (.github/workflows/build.yml) genera el APK y lo publica en Releases.
