package com.paso.podometro

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Locale

data class User(val id: Long, val name: String, val heightCm: Double, val goalSteps: Int, val goalKm: Double)

data class WeightEntry(val id: Long, val ts: Long, val kg: Double)

data class Session(
    val id: Long,
    val startTs: Long,
    val endTs: Long,
    val steps: Int,
    val distM: Double,
    val kcal: Double,
    val route: List<Pair<Double, Double>>
) {
    val durationS: Long get() = ((endTs - startTs) / 1000).coerceAtLeast(0)
}

fun encodeRoute(r: List<Pair<Double, Double>>): String =
    r.joinToString(";") { String.format(Locale.US, "%.5f,%.5f", it.first, it.second) }

fun decodeRoute(s: String?): List<Pair<Double, Double>> {
    if (s.isNullOrBlank()) return emptyList()
    return s.split(";").mapNotNull { p ->
        val a = p.split(",")
        val la = a.getOrNull(0)?.toDoubleOrNull()
        val lo = a.getOrNull(1)?.toDoubleOrNull()
        if (la != null && lo != null) la to lo else null
    }
}

class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "podometro.db", null, 1) {

    companion object {
        @Volatile
        private var inst: Db? = null
        fun get(ctx: Context): Db = inst ?: synchronized(Db::class.java) {
            inst ?: Db(ctx.applicationContext).also { inst = it }
        }
    }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, height_cm REAL, goal_steps INTEGER, goal_km REAL)")
        d.execSQL("CREATE TABLE weights(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, ts INTEGER, kg REAL)")
        d.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, start_ts INTEGER, end_ts INTEGER, steps INTEGER, dist_m REAL, kcal REAL, route TEXT)")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun users(): List<User> {
        val out = mutableListOf<User>()
        readableDatabase.rawQuery("SELECT id,name,height_cm,goal_steps,goal_km FROM users ORDER BY id", null).use { c ->
            while (c.moveToNext()) {
                out.add(User(c.getLong(0), c.getString(1) ?: "", c.getDouble(2), c.getInt(3), c.getDouble(4)))
            }
        }
        return out
    }

    fun addUser(name: String, heightCm: Double, kg: Double, goalSteps: Int, goalKm: Double): Long {
        val v = ContentValues()
        v.put("name", name)
        v.put("height_cm", heightCm)
        v.put("goal_steps", goalSteps)
        v.put("goal_km", goalKm)
        val id = writableDatabase.insert("users", null, v)
        addWeight(id, kg)
        return id
    }

    fun updateUser(u: User) {
        val v = ContentValues()
        v.put("name", u.name)
        v.put("height_cm", u.heightCm)
        v.put("goal_steps", u.goalSteps)
        v.put("goal_km", u.goalKm)
        writableDatabase.update("users", v, "id=?", arrayOf(u.id.toString()))
    }

    fun deleteUser(id: Long) {
        val a = arrayOf(id.toString())
        val d = writableDatabase
        d.delete("weights", "user_id=?", a)
        d.delete("sessions", "user_id=?", a)
        d.delete("users", "id=?", a)
    }

    fun weights(userId: Long): List<WeightEntry> {
        val out = mutableListOf<WeightEntry>()
        readableDatabase.rawQuery(
            "SELECT id,ts,kg FROM weights WHERE user_id=? ORDER BY ts ASC, id ASC",
            arrayOf(userId.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(WeightEntry(c.getLong(0), c.getLong(1), c.getDouble(2)))
        }
        return out
    }

    fun addWeight(userId: Long, kg: Double, ts: Long = System.currentTimeMillis()) {
        val v = ContentValues()
        v.put("user_id", userId)
        v.put("ts", ts)
        v.put("kg", kg)
        writableDatabase.insert("weights", null, v)
    }

    fun updateWeight(id: Long, kg: Double) {
        val v = ContentValues()
        v.put("kg", kg)
        writableDatabase.update("weights", v, "id=?", arrayOf(id.toString()))
    }

    fun deleteWeight(id: Long) {
        writableDatabase.delete("weights", "id=?", arrayOf(id.toString()))
    }

    fun latestWeight(userId: Long): Double? = weights(userId).lastOrNull()?.kg

    fun sessions(userId: Long): List<Session> {
        val out = mutableListOf<Session>()
        readableDatabase.rawQuery(
            "SELECT id,start_ts,end_ts,steps,dist_m,kcal,route FROM sessions WHERE user_id=? ORDER BY start_ts DESC",
            arrayOf(userId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    Session(
                        c.getLong(0), c.getLong(1), c.getLong(2), c.getInt(3),
                        c.getDouble(4), c.getDouble(5), decodeRoute(c.getString(6))
                    )
                )
            }
        }
        return out
    }

    fun addSession(
        userId: Long, startTs: Long, endTs: Long, steps: Int, distM: Double, kcal: Double,
        route: List<Pair<Double, Double>>
    ) {
        val v = ContentValues()
        v.put("user_id", userId)
        v.put("start_ts", startTs)
        v.put("end_ts", endTs)
        v.put("steps", steps)
        v.put("dist_m", distM)
        v.put("kcal", kcal)
        v.put("route", encodeRoute(route))
        writableDatabase.insert("sessions", null, v)
    }

    fun deleteSession(id: Long) {
        writableDatabase.delete("sessions", "id=?", arrayOf(id.toString()))
    }
}
