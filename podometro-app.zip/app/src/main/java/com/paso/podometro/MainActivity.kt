package com.paso.podometro

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Orange = Color(0xFFE8710A)
val Green = Color(0xFF4C8C2B)
val Cream = Color(0xFFFFF8EE)
val Sand = Color(0xFFFFE9CC)
val Red = Color(0xFFC0392B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PodometroTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App()
                }
            }
        }
    }
}

@Composable
fun PodometroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Orange,
            onPrimary = Color.White,
            secondary = Green,
            background = Cream,
            surface = Color.White,
            surfaceVariant = Sand,
            primaryContainer = Sand,
            onPrimaryContainer = Color(0xFF4A2A00)
        ),
        content = content
    )
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    var users by remember { mutableStateOf(db.users()) }
    var userId by remember { mutableLongStateOf(prefs.getLong("user", -1L)) }
    var tab by remember { mutableIntStateOf(0) }
    val user = users.firstOrNull { it.id == userId } ?: users.firstOrNull()

    if (user == null) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 40.dp)) {
            Text(
                "👣 ¡Bienvenido al Podómetro!",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Orange,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            NewUserForm("Creá tu perfil", { name, h, kg, gs, gk ->
                val id = db.addUser(name, h, kg, gs, gk)
                prefs.edit().putLong("user", id).apply()
                users = db.users()
                userId = id
            }, null)
        }
    } else {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("👣" to "Caminar", "📅" to "Historial", "👤" to "Perfil").forEachIndexed { i, (e, l) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(e, fontSize = 22.sp) },
                            label = { Text(l) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> WalkScreen(db, prefs, user)
                    1 -> HistoryScreen(db, user)
                    else -> ProfileScreen(
                        db, users, user,
                        onUsersChanged = { users = db.users() },
                        onSelect = { id ->
                            userId = id
                            prefs.edit().putLong("user", id).apply()
                        },
                        onDeleted = {
                            users = db.users()
                            userId = users.firstOrNull()?.id ?: -1L
                            prefs.edit().putLong("user", userId).apply()
                        }
                    )
                }
            }
        }
    }
}
