package com.paso.podometro

import android.Manifest
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun dayKey(ts: Long): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ts))

fun toNum(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

@Composable
fun NumField(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun Stat(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Orange)
        Text(label, fontSize = 12.sp, color = Color(0xFF6B5B4B))
    }
}

@Composable
fun WhiteCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
fun RouteCanvas(points: List<Pair<Double, Double>>) {
    Canvas(
        Modifier.fillMaxWidth().height(200.dp).background(Color(0xFFFFF1DC), RoundedCornerShape(12.dp))
    ) {
        if (points.size < 2) return@Canvas
        val minLat = points.minOf { it.first }
        val maxLat = points.maxOf { it.first }
        val minLon = points.minOf { it.second }
        val maxLon = points.maxOf { it.second }
        val kx = Math.cos(Math.toRadians((minLat + maxLat) / 2))
        val w = ((maxLon - minLon) * kx).coerceAtLeast(1e-6)
        val h = (maxLat - minLat).coerceAtLeast(1e-6)
        val pad = 24f
        val sc = minOf((size.width - 2 * pad).toDouble() / w, (size.height - 2 * pad).toDouble() / h)
        val ox = (size.width - (w * sc).toFloat()) / 2f
        val oy = (size.height - (h * sc).toFloat()) / 2f
        fun pt(p: Pair<Double, Double>): Offset =
            Offset(ox + (((p.second - minLon) * kx) * sc).toFloat(), oy + ((maxLat - p.first) * sc).toFloat())
        val path = Path()
        val first = pt(points.first())
        path.moveTo(first.x, first.y)
        for (i in 1 until points.size) {
            val o = pt(points[i])
            path.lineTo(o.x, o.y)
        }
        drawPath(path, Orange, style = Stroke(width = 6f, cap = StrokeCap.Round))
        drawCircle(Green, 10f, first)
        drawCircle(Red, 10f, pt(points.last()))
    }
}

@Composable
fun WeightChart(all: List<WeightEntry>) {
    val ws = all.takeLast(30)
    Canvas(
        Modifier.fillMaxWidth().height(150.dp).background(Color(0xFFFFF1DC), RoundedCornerShape(12.dp))
    ) {
        if (ws.size < 2) return@Canvas
        val mn = ws.minOf { it.kg }
        val mx = ws.maxOf { it.kg }
        val range = (mx - mn).coerceAtLeast(0.5)
        val pad = 24f
        val stepX = (size.width - 2 * pad) / (ws.size - 1)
        fun pt(i: Int): Offset =
            Offset(pad + stepX * i, pad + ((mx - ws[i].kg) / range).toFloat() * (size.height - 2 * pad))
        val path = Path()
        val p0 = pt(0)
        path.moveTo(p0.x, p0.y)
        for (i in 1 until ws.size) {
            val o = pt(i)
            path.lineTo(o.x, o.y)
        }
        drawPath(path, Green, style = Stroke(width = 5f, cap = StrokeCap.Round))
        for (i in ws.indices) drawCircle(Orange, 8f, pt(i))
    }
}

// ---------------------------------------------------------------- CAMINAR

@Composable
fun WalkScreen(db: Db, prefs: SharedPreferences, user: User) {
    val ctx = LocalContext.current
    var weather by remember { mutableStateOf<Weather.Info?>(null) }
    var wStatus by remember { mutableStateOf("Buscando clima…") }
    var announceKm by remember { mutableIntStateOf(prefs.getInt("announce", 1)) }
    var voice by remember { mutableStateOf(prefs.getBoolean("voice", true)) }
    var wantStart by remember { mutableStateOf(false) }
    val sessions = remember(user.id, TrackState.savedTick) { db.sessions(user.id) }

    fun loadWeather() {
        wStatus = "Buscando clima…"
        LocationHelper.current(ctx) { loc ->
            if (loc == null) {
                wStatus = "Activá el GPS y los permisos para ver el clima"
            } else {
                Thread {
                    val w = Weather.fetch(loc.latitude, loc.longitude)
                    Handler(Looper.getMainLooper()).post {
                        weather = w
                        wStatus = if (w == null) "No se pudo obtener el clima (¿hay internet?)" else ""
                    }
                }.start()
            }
        }
    }

    fun doStart() {
        val kg = db.latestWeight(user.id) ?: 70.0
        TrackingService.start(ctx, user.id, kg, user.heightCm, announceKm, voice, weather?.summary())
    }

    val perms = remember {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 29) l.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        l.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        loadWeather()
        if (wantStart && hasFineLocation(ctx)) {
            wantStart = false
            doStart()
        }
    }
    LaunchedEffect(Unit) {
        if (!hasFineLocation(ctx)) launcher.launch(perms) else loadWeather()
    }

    val live = TrackState.running
    val today = dayKey(System.currentTimeMillis())
    val todayS = sessions.filter { dayKey(it.startTs) == today }
    val steps = todayS.sumOf { it.steps } + (if (live) TrackState.steps else 0)
    val distM = todayS.sumOf { it.distM } + (if (live) TrackState.distM else 0.0)
    val kcal = todayS.sumOf { it.kcal } + (if (live) TrackState.kcal else 0.0)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Hola, ${user.name} 👋", fontSize = 26.sp, fontWeight = FontWeight.Bold)

        WhiteCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("🌤 Clima ahora", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                TextButton(onClick = { loadWeather() }) { Text("Actualizar") }
            }
            val w = weather
            if (w == null) {
                Text(wStatus)
            } else {
                Text("${w.desc} · ${Fmt.d1(w.temp)}°C (sensación ${Fmt.d1(w.feels)}°C)", fontSize = 16.sp)
                Text("💨 Viento ${Fmt.d1(w.wind)} km/h · 🌧 Lluvia ${Fmt.d1(w.rain)} mm")
                Text(w.advice, color = Green, fontWeight = FontWeight.Bold)
            }
        }

        WhiteCard {
            Text(if (live) "🔴 Caminata en curso" else "Hoy", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("$steps", "pasos")
                Stat(Fmt.km(distM), "km")
                Stat("${kcal.toInt()}", "kcal")
                if (live) Stat(Fmt.dur(TrackState.elapsedS), "tiempo")
            }
            Text("Meta de pasos: ${user.goalSteps}", fontSize = 13.sp)
            LinearProgressIndicator(
                progress = { (steps.toFloat() / user.goalSteps.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(10.dp),
                color = Orange,
                trackColor = Sand
            )
            Text("Meta de distancia: ${Fmt.d1(user.goalKm)} km", fontSize = 13.sp)
            LinearProgressIndicator(
                progress = { ((distM / 1000.0) / user.goalKm.coerceAtLeast(0.1)).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(10.dp),
                color = Green,
                trackColor = Sand
            )
        }

        if (live && TrackState.route.size >= 2) {
            RouteCanvas(TrackState.route.toList())
        }

        Button(
            onClick = {
                if (live) {
                    TrackingService.stop(ctx)
                } else if (!hasFineLocation(ctx)) {
                    wantStart = true
                    launcher.launch(perms)
                } else {
                    doStart()
                }
            },
            modifier = Modifier.fillMaxWidth().height(64.dp),
            colors = if (live) ButtonDefaults.buttonColors(containerColor = Red) else ButtonDefaults.buttonColors()
        ) {
            Text(if (live) "⏹ Detener y guardar" else "▶ Comenzar a caminar", fontSize = 20.sp)
        }

        WhiteCard {
            Text("🔊 Aviso por voz", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Avisar cada distancia")
                Switch(
                    checked = voice,
                    onCheckedChange = {
                        voice = it
                        prefs.edit().putBoolean("voice", it).apply()
                    },
                    enabled = !live
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 5, 10).forEach { km ->
                    FilterChip(
                        selected = announceKm == km,
                        onClick = {
                            announceKm = km
                            prefs.edit().putInt("announce", km).apply()
                        },
                        label = { Text("cada $km km") },
                        enabled = !live
                    )
                }
            }
            Text("Sigue contando con la pantalla apagada mientras la notificación esté activa.", fontSize = 12.sp, color = Color(0xFF6B5B4B))
        }
    }
}

// ---------------------------------------------------------------- HISTORIAL

@Composable
fun HistoryScreen(db: Db, user: User) {
    var tick by remember { mutableIntStateOf(0) }
    val sessions = remember(user.id, tick, TrackState.savedTick) { db.sessions(user.id) }
    var openId by remember { mutableLongStateOf(-1L) }
    var toDelete by remember { mutableStateOf<Session?>(null) }
    val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
    val week = sessions.filter { it.startTs >= weekAgo }
    val groups = sessions.groupBy { dayKey(it.startTs) }
    val dayFmt = remember { SimpleDateFormat("EEEE d 'de' MMMM yyyy", Locale("es", "AR")) }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Historial", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                WhiteCard {
                    Text("Últimos 7 días", fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Stat("${week.sumOf { it.steps }}", "pasos")
                        Stat(Fmt.km(week.sumOf { it.distM }), "km")
                        Stat("${week.sumOf { it.kcal }.toInt()}", "kcal")
                    }
                }
            }
        }
        if (groups.isEmpty()) {
            item { Text("Todavía no hay caminatas guardadas. ¡Salí a caminar!") }
        }
        groups.forEach { (k, list) ->
            item(key = k) {
                WhiteCard {
                    Text(
                        dayFmt.format(Date(list.first().startTs)).replaceFirstChar { it.uppercase() },
                        fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Orange
                    )
                    Text(
                        "Total del día: ${list.sumOf { it.steps }} pasos · ${Fmt.km(list.sumOf { it.distM })} km · " +
                            "${list.sumOf { it.kcal }.toInt()} kcal · ${Fmt.dur(list.sumOf { it.durationS })}",
                        fontSize = 14.sp
                    )
                    for (s in list) {
                        HorizontalDivider()
                        Text(
                            "${timeFmt.format(Date(s.startTs))} – ${timeFmt.format(Date(s.endTs))}  ·  ${s.steps} pasos · " +
                                "${Fmt.km(s.distM)} km · ${s.kcal.toInt()} kcal · ${Fmt.dur(s.durationS)}",
                            fontSize = 14.sp
                        )
                        Row {
                            TextButton(onClick = { openId = if (openId == s.id) -1L else s.id }) {
                                Text(if (openId == s.id) "Ocultar ruta" else "🗺 Ver ruta")
                            }
                            TextButton(onClick = { toDelete = s }) { Text("🗑 Borrar", color = Red) }
                        }
                        if (openId == s.id) {
                            if (s.route.size >= 2) RouteCanvas(s.route) else Text("Esta caminata no tiene ruta registrada.")
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { s ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Borrar esta caminata?") },
            text = { Text("${s.steps} pasos · ${Fmt.km(s.distM)} km. No se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    db.deleteSession(s.id)
                    toDelete = null
                    tick++
                }) { Text("Borrar", color = Red) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

// ---------------------------------------------------------------- PERFIL

@Composable
fun NewUserForm(
    title: String,
    onCreate: (String, Double, Double, Int, Double) -> Unit,
    onCancel: (() -> Unit)?
) {
    var name by remember { mutableStateOf("") }
    var h by remember { mutableStateOf("") }
    var kg by remember { mutableStateOf("") }
    var gs by remember { mutableStateOf("8000") }
    var gk by remember { mutableStateOf("5") }
    var err by remember { mutableStateOf("") }
    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = name, onValueChange = { name = it }, label = { Text("Nombre") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        NumField(h, { h = it }, "Altura (cm)")
        NumField(kg, { kg = it }, "Peso actual (kg)")
        NumField(gs, { gs = it }, "Meta diaria de pasos")
        NumField(gk, { gk = it }, "Meta diaria de distancia (km)")
        if (err.isNotEmpty()) Text(err, color = Red)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (onCancel != null) OutlinedButton(onClick = onCancel) { Text("Cancelar") }
            Button(onClick = {
                val hv = toNum(h)
                val kv = toNum(kg)
                val sv = toNum(gs)
                val kmv = toNum(gk)
                if (name.isBlank()) err = "Poné un nombre"
                else if (hv == null || hv < 80 || hv > 250) err = "Altura inválida (80 a 250 cm)"
                else if (kv == null || kv < 20 || kv > 400) err = "Peso inválido"
                else if (sv == null || sv < 1) err = "Meta de pasos inválida"
                else if (kmv == null || kmv <= 0) err = "Meta de distancia inválida"
                else onCreate(name.trim(), hv, kv, sv.toInt(), kmv)
            }) { Text("Guardar") }
        }
    }
}

@Composable
fun ProfileScreen(
    db: Db,
    users: List<User>,
    user: User,
    onUsersChanged: () -> Unit,
    onSelect: (Long) -> Unit,
    onDeleted: () -> Unit
) {
    var name by remember(user.id) { mutableStateOf(user.name) }
    var height by remember(user.id) { mutableStateOf(Fmt.d1(user.heightCm)) }
    var goalSteps by remember(user.id) { mutableStateOf(user.goalSteps.toString()) }
    var goalKm by remember(user.id) { mutableStateOf(Fmt.d1(user.goalKm)) }
    var msg by remember(user.id) { mutableStateOf("") }
    var wTick by remember { mutableIntStateOf(0) }
    val weights = remember(user.id, wTick) { db.weights(user.id) }
    var newKg by remember(user.id) { mutableStateOf("") }
    var editing by remember { mutableStateOf<WeightEntry?>(null) }
    var editKg by remember { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val dateFmt = remember { SimpleDateFormat("d MMM yyyy", Locale("es", "AR")) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Perfil", fontSize = 26.sp, fontWeight = FontWeight.Bold)

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            users.forEach { u ->
                FilterChip(selected = u.id == user.id, onClick = { onSelect(u.id) }, label = { Text(u.name) })
            }
            OutlinedButton(onClick = { showNew = true }) { Text("+ Nuevo usuario") }
        }

        WhiteCard {
            Text("Mis datos", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            OutlinedTextField(
                value = name, onValueChange = { name = it }, label = { Text("Nombre") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            NumField(height, { height = it }, "Altura (cm)")
            NumField(goalSteps, { goalSteps = it }, "Meta diaria de pasos")
            NumField(goalKm, { goalKm = it }, "Meta diaria de distancia (km)")
            Button(onClick = {
                val hv = toNum(height)
                val sv = toNum(goalSteps)
                val kv = toNum(goalKm)
                if (name.isBlank() || hv == null || hv < 80 || hv > 250 || sv == null || sv < 1 || kv == null || kv <= 0) {
                    msg = "Revisá los datos"
                } else {
                    db.updateUser(User(user.id, name.trim(), hv, sv.toInt(), kv))
                    onUsersChanged()
                    msg = "Guardado ✔"
                }
            }) { Text("Guardar cambios") }
            if (msg.isNotEmpty()) Text(msg, color = Green)
        }

        WhiteCard {
            Text("⚖ Evolución del peso", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            if (weights.isNotEmpty()) {
                Text("Peso actual: ${Fmt.d1(weights.last().kg)} kg", fontSize = 18.sp, color = Orange, fontWeight = FontWeight.Bold)
            }
            if (weights.size >= 2) {
                val diff = weights.last().kg - weights.first().kg
                val sign = if (diff > 0) "+" else ""
                Text("Cambio desde el primer registro: $sign${Fmt.d1(diff)} kg")
                WeightChart(weights)
            }
            NumField(newKg, { newKg = it }, "Nuevo peso (kg)")
            Button(onClick = {
                val v = toNum(newKg)
                if (v != null && v in 20.0..400.0) {
                    db.addWeight(user.id, v)
                    newKg = ""
                    wTick++
                }
            }) { Text("Registrar peso") }
            HorizontalDivider()
            weights.asReversed().take(20).forEach { w ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${dateFmt.format(Date(w.ts))}:  ${Fmt.d1(w.kg)} kg", modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        editing = w
                        editKg = Fmt.d1(w.kg)
                    }) { Text("Editar") }
                    TextButton(onClick = {
                        if (weights.size > 1) {
                            db.deleteWeight(w.id)
                            wTick++
                        }
                    }) { Text("🗑", color = Red) }
                }
            }
        }

        OutlinedButton(onClick = { confirmDelete = true }) { Text("Eliminar este usuario", color = Red) }
    }

    editing?.let { w ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Modificar peso") },
            text = { NumField(editKg, { editKg = it }, "Peso (kg)") },
            confirmButton = {
                TextButton(onClick = {
                    val v = toNum(editKg)
                    if (v != null && v in 20.0..400.0) {
                        db.updateWeight(w.id, v)
                        editing = null
                        wTick++
                    }
                }) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancelar") } }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Eliminar a ${user.name}?") },
            text = { Text("Se borran también sus pesos y su historial de caminatas.") },
            confirmButton = {
                TextButton(onClick = {
                    db.deleteUser(user.id)
                    confirmDelete = false
                    onDeleted()
                }) { Text("Eliminar", color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }

    if (showNew) {
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    NewUserForm("Nuevo usuario", { n, h, kg, gs, gk ->
                        val id = db.addUser(n, h, kg, gs, gk)
                        showNew = false
                        onUsersChanged()
                        onSelect(id)
                    }, { showNew = false })
                }
            }
        }
    }
}
