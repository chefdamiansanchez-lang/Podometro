package com.paso.podometro

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** Estado en vivo de la caminata, compartido entre el servicio y la pantalla. */
object TrackState {
    var running by mutableStateOf(false)
    var steps by mutableIntStateOf(0)
    var distM by mutableDoubleStateOf(0.0)
    var kcal by mutableDoubleStateOf(0.0)
    var elapsedS by mutableLongStateOf(0L)
    var savedTick by mutableIntStateOf(0)
    val route = mutableStateListOf<Pair<Double, Double>>()

    fun reset() {
        steps = 0
        distM = 0.0
        kcal = 0.0
        elapsedS = 0L
        route.clear()
    }
}

object Fmt {
    fun km(m: Double): String = String.format(Locale.getDefault(), "%.2f", m / 1000.0)
    fun d1(x: Double): String = String.format(Locale.getDefault(), "%.1f", x)
    fun dur(s: Long): String {
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return String.format(Locale.getDefault(), "%d:%02d:%02d", h, m, sec)
    }
}
