package com.paso.podometro

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.core.content.ContextCompat
import java.util.Locale

class TrackingService : Service(), SensorEventListener, LocationListener, TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "com.paso.podometro.START"
        const val ACTION_STOP = "com.paso.podometro.STOP"
        const val CHANNEL = "tracking"

        fun start(
            ctx: Context, userId: Long, weightKg: Double, heightCm: Double,
            announceKm: Int, voice: Boolean, weather: String?
        ) {
            val i = Intent(ctx, TrackingService::class.java)
            i.action = ACTION_START
            i.putExtra("user", userId)
            i.putExtra("weight", weightKg)
            i.putExtra("height", heightCm)
            i.putExtra("km", announceKm)
            i.putExtra("voice", voice)
            i.putExtra("weather", weather ?: "")
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            val i = Intent(ctx, TrackingService::class.java)
            i.action = ACTION_STOP
            ctx.startService(i)
        }
    }

    private var lm: LocationManager? = null
    private var sm: SensorManager? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val queue = mutableListOf<String>()
    private val handler = Handler(Looper.getMainLooper())

    private var userId = -1L
    private var weightKg = 70.0
    private var strideM = 0.72
    private var announceM = 1000.0
    private var nextAnnounce = 1000.0
    private var voice = true
    private var startTs = 0L
    private var baseSteps = -1f
    private var hasStepSensor = false
    private var lastLoc: Location? = null
    private var active = false

    private val ticker = object : Runnable {
        override fun run() {
            if (!active) return
            TrackState.elapsedS = (System.currentTimeMillis() - startTs) / 1000
            updateNotification()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val act = intent?.action
        if (act == ACTION_STOP) {
            finishSession()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (act == ACTION_START && !active) {
            begin(intent)
        }
        return START_NOT_STICKY
    }

    private fun begin(i: Intent) {
        userId = i.getLongExtra("user", -1L)
        weightKg = i.getDoubleExtra("weight", 70.0)
        val h = i.getDoubleExtra("height", 170.0)
        strideM = (h / 100.0 * 0.415).coerceIn(0.4, 1.2)
        announceM = i.getIntExtra("km", 1) * 1000.0
        nextAnnounce = announceM
        voice = i.getBooleanExtra("voice", true)
        val weather = i.getStringExtra("weather") ?: ""

        createChannel()
        val n = buildNotification("Iniciando…")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(1, n)
        }

        TrackState.reset()
        TrackState.running = true
        startTs = System.currentTimeMillis()
        active = true

        if (voice) {
            queue.add(if (weather.isBlank()) "Comenzamos la caminata." else "Comenzamos la caminata. $weather")
            tts = TextToSpeech(this, this)
        }
        startSensors()
        handler.post(ticker)
    }

    @SuppressLint("MissingPermission")
    private fun startSensors() {
        val s = getSystemService(SENSOR_SERVICE) as SensorManager
        sm = s
        val permOk = Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) ==
            PackageManager.PERMISSION_GRANTED
        val sensor = s.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (permOk && sensor != null) {
            hasStepSensor = s.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI)
        }
        val l = getSystemService(LOCATION_SERVICE) as LocationManager
        lm = l
        try {
            l.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 0f, this)
        } catch (e: SecurityException) {
        } catch (e: IllegalArgumentException) {
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (!active) return
        val v = e.values[0]
        if (baseSteps < 0) baseSteps = v
        TrackState.steps = (v - baseSteps).toInt()
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    override fun onLocationChanged(location: Location) {
        if (!active || location.accuracy > 35f) return
        val last = lastLoc
        if (last == null) {
            lastLoc = location
            TrackState.route.add(location.latitude to location.longitude)
            return
        }
        val d = last.distanceTo(location)
        if (d < 4f) return
        if (d > 200f && (location.time - last.time) < 5000) return
        lastLoc = location
        TrackState.distM += d.toDouble()
        TrackState.route.add(location.latitude to location.longitude)
        if (!hasStepSensor) TrackState.steps = (TrackState.distM / strideM).toInt()
        TrackState.kcal = weightKg * (TrackState.distM / 1000.0) * 0.95
        checkAnnounce()
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    private fun checkAnnounce() {
        while (TrackState.distM >= nextAnnounce) {
            val km = (nextAnnounce / 1000.0).toInt()
            val unidad = if (km == 1) "kilómetro" else "kilómetros"
            speak(
                "Has recorrido $km $unidad en ${spokenTime(TrackState.elapsedS)}. " +
                    "Calorías quemadas: ${TrackState.kcal.toInt()}."
            )
            nextAnnounce += announceM
        }
    }

    private fun spokenTime(s: Long): String {
        val totalMin = s / 60
        val h = totalMin / 60
        val m = totalMin % 60
        return when {
            h > 0 -> "$h ${if (h == 1L) "hora" else "horas"} y $m minutos"
            else -> "$m ${if (m == 1L) "minuto" else "minutos"}"
        }
    }

    private fun speak(t: String) {
        if (!voice) return
        if (ttsReady) {
            tts?.speak(t, TextToSpeech.QUEUE_ADD, null, "p" + System.nanoTime())
        } else {
            queue.add(t)
        }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val t = tts ?: return
        val r = t.setLanguage(Locale("es", "AR"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale("es"))
        }
        ttsReady = true
        for (q in queue) t.speak(q, TextToSpeech.QUEUE_ADD, null, "q" + System.nanoTime())
        queue.clear()
    }

    private fun finishSession() {
        if (!active) return
        active = false
        handler.removeCallbacks(ticker)
        try {
            lm?.removeUpdates(this)
        } catch (e: Exception) {
        }
        sm?.unregisterListener(this)
        val end = System.currentTimeMillis()
        if (TrackState.distM > 10 || TrackState.steps > 10) {
            Db.get(this).addSession(
                userId, startTs, end, TrackState.steps, TrackState.distM, TrackState.kcal,
                TrackState.route.toList()
            )
        }
        TrackState.running = false
        TrackState.savedTick++
    }

    override fun onDestroy() {
        finishSession()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Caminata en curso", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Podómetro activo")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification() {
        val t = "${TrackState.steps} pasos · ${Fmt.km(TrackState.distM)} km · ${Fmt.dur(TrackState.elapsedS)}"
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(t))
    }
}
