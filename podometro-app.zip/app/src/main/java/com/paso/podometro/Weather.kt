package com.paso.podometro

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

object Weather {

    data class Info(val temp: Double, val feels: Double, val wind: Double, val rain: Double, val code: Int) {
        val desc: String
            get() = when (code) {
                0 -> "Despejado"
                1, 2 -> "Mayormente despejado"
                3 -> "Nublado"
                45, 48 -> "Niebla"
                in 51..57 -> "Llovizna"
                in 61..67 -> "Lluvia"
                in 71..77 -> "Nieve"
                in 80..82 -> "Chubascos"
                in 95..99 -> "Tormenta"
                else -> "Variable"
            }

        val advice: String
            get() = when {
                code in 95..99 -> "Hay tormenta, mejor esperar antes de salir."
                rain > 0.2 || code in 51..67 || code in 80..82 -> "Hay lluvia, llevá impermeable."
                temp >= 32 -> "Hace mucho calor, llevá agua y evitá las horas pico."
                temp <= 5 -> "Hace frío, abrigate bien."
                wind >= 35 -> "Hay viento fuerte, tené precaución."
                else -> "Buen momento para caminar."
            }

        fun summary(): String =
            "Condiciones actuales: $desc, ${temp.roundToInt()} grados, sensación térmica ${feels.roundToInt()}, " +
                "viento ${wind.roundToInt()} kilómetros por hora. $advice"
    }

    fun fetch(lat: Double, lon: Double): Info? {
        return try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&timezone=auto"
            )
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            val cur = JSONObject(txt).getJSONObject("current")
            Info(
                cur.getDouble("temperature_2m"),
                cur.getDouble("apparent_temperature"),
                cur.getDouble("wind_speed_10m"),
                cur.getDouble("precipitation"),
                cur.getInt("weather_code")
            )
        } catch (e: Exception) {
            null
        }
    }
}

fun hasFineLocation(ctx: Context): Boolean =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

object LocationHelper {
    @SuppressLint("MissingPermission")
    fun current(ctx: Context, cb: (Location?) -> Unit) {
        val fine = hasFineLocation(ctx)
        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            cb(null)
            return
        }
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            try {
                val l = lm.getLastKnownLocation(p)
                val b = best
                if (l != null && (b == null || l.time > b.time)) best = l
            } catch (e: Exception) {
            }
        }
        val found = best
        if (found != null) {
            cb(found)
            return
        }
        val prov = when {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }
        if (prov == null) {
            cb(null)
            return
        }
        try {
            lm.requestSingleUpdate(prov, object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    cb(location)
                }

                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }, Looper.getMainLooper())
        } catch (e: Exception) {
            cb(null)
        }
    }
}
